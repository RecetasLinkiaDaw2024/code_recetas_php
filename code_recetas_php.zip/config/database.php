<?php
//Configuraciones globales de acceso a base datos, seteadas como constantes

define("DB_SERVER","sql.freedb.tech");
define("DB_USER","freedb_recetasdaw");
define("DB_PASS",'@g%TRXwD%!z8dFv');
define("DB_DATABASE","freedb_recetasdaw");
define("DB_PORT",3306);


?>