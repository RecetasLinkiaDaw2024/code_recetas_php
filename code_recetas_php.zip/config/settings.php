<?php
//Configuraciones globales seteadas como constantes

// Las config deben ser constantes para evitar que se reescriban
// las declaracionesd e constantes deberia hacerse en la carpeta config y solo en esa carpeta.

//ejemplo
//define("DB_SERVER","sql.freedb.tech");


?>