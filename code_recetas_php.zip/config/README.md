## Carpeta con la definicion de constantes 

En esta carpeta tiene los archivos php con los settings de la aplicación, como por ejemplo, **database.php**, que tiene la configfuración de acceos a datos.
