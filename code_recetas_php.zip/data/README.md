## Carpeta con lso metodos de acceso a BBDD.

En esta carpeta se ubican los metodos de acxceso a los datos.
De esta forma todas las paginas las pueden reutrilizar y si hace falta añadir alguno, lo añadimos en el archivo más adecuado o ceraomos uno especifico para ello, **pero aqui**.

