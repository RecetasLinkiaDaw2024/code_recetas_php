## Carpeta elementos publicos estaticos

En esta carpeta guardaremos todo los elementos estaticos que dan soporte a la aplicación.

1. **css**: Archivos con estilos css
2. **js**: Archivos con scripts js a utilizar en la web
3. **img**: Archivos con imagenes como logo, etc.
