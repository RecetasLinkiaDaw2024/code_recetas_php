<?php
//archivo index para redirigir a la pantalla base de la aplicación
//por ahora vamos a las pruebas
header('Location: pruebas/');
?>