## Carpeta con los servicios web REST

En esta carpeta se ubican los scripts de los servicios REST de la aplicación.

Cuando tengamos que obtener datos de forma asincrona, ubicaremos el php con el servicio REST aqui, en esta carpeta o en una subcarpeta si es muy especifico.

