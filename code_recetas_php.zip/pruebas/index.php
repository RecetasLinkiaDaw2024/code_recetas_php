<?php
//archivo index para redirigir a la pantalla base
require_once (__DIR__."/view/listado_datos.php");
?>